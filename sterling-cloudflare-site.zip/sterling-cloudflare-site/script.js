const menuButton = document.querySelector('.menu-button');
const mobileNav = document.getElementById('mobileNav');
if (menuButton && mobileNav) {
  menuButton.addEventListener('click', () => mobileNav.classList.toggle('open'));
  mobileNav.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => mobileNav.classList.remove('open')));
}

const chatToggle = document.getElementById('chatToggle');
const chatWindow = document.getElementById('chatWindow');
const closeChat = document.getElementById('closeChat');
if (chatToggle && chatWindow) chatToggle.addEventListener('click', () => chatWindow.classList.toggle('open'));
if (closeChat && chatWindow) closeChat.addEventListener('click', () => chatWindow.classList.remove('open'));
